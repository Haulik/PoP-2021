How to compile and run the code

Navigate via Terminal/CMD to the ../src folder. 
Use the command "fsharpc -r img_util.dll 4i1.fsx" to compile 4i1..fsx
Use the command "mono 4i1.exe" to run 4i1.exe
