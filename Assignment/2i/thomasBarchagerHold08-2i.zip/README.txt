To run the F# code in the src folder:
- Open Terminal/CMD
- Navigate to correct folder (../src)
- Type "fsharpi 2i1.fsx" into the Terminal/CMD


To translate the Latexcode to pdf, in the tex folder:
- Open Terminal/CMD
- Navigate to correct folder (../tex)
- Type "pdflatex Latext-2i.txt"

